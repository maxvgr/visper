/* Подключение стилей библиотек */
import "modern-normalize";

/* Подключение стилей проекта */
import '../scss/main.scss';

/* Подключение скриптов */
import './global/init';

import './layout/header';
import './layout/menu';

/* Подключение cnhfybw */
import './layout/page/home';

import './layout/section/contacts-map';
